-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 14-04-2021 a las 21:39:20
-- Versión del servidor: 5.7.30
-- Versión de PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `houserental`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `House`
--

CREATE TABLE `House` (
  `idHouse` int(110) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(150) NOT NULL,
  `imageHouse` varchar(200) NOT NULL,
  `numRooms` int(11) NOT NULL,
  `numBath` int(11) NOT NULL,
  `parking` varchar(45) NOT NULL,
  `serviceInternet` varchar(45) NOT NULL,
  `aditionalServices` varchar(100) NOT NULL,
  `priceAlquiler` int(100) NOT NULL,
  `location` varchar(45) NOT NULL,
  `startDateAvail` date NOT NULL,
  `endDateAvail` date NOT NULL,
  `capacity` varchar(45) NOT NULL,
  `idUser` int(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Rental`
--

CREATE TABLE `Rental` (
  `idRental` int(110) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `priceRental` varchar(45) NOT NULL,
  `idUser` int(110) NOT NULL,
  `idHouse` int(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `User`
--

CREATE TABLE `User` (
  `idUser` int(110) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(100) NOT NULL,
  `city` varchar(45) NOT NULL,
  `dpr` varchar(45) NOT NULL,
  `roles` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `House`
--
ALTER TABLE `House`
  ADD PRIMARY KEY (`idHouse`),
  ADD KEY `fk_UserHouse` (`idUser`);

--
-- Indices de la tabla `Rental`
--
ALTER TABLE `Rental`
  ADD PRIMARY KEY (`idRental`),
  ADD KEY `fk_UserRental` (`idUser`),
  ADD KEY `fk_HouseRental` (`idHouse`);

--
-- Indices de la tabla `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `House`
--
ALTER TABLE `House`
  MODIFY `idHouse` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `Rental`
--
ALTER TABLE `Rental`
  MODIFY `idRental` int(110) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(110) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `House`
--
ALTER TABLE `House`
  ADD CONSTRAINT `fk_UserHouse` FOREIGN KEY (`idUser`) REFERENCES `User` (`idUser`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `Rental`
--
ALTER TABLE `Rental`
  ADD CONSTRAINT `fk_HouseRental` FOREIGN KEY (`idHouse`) REFERENCES `House` (`idHouse`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_UserRental` FOREIGN KEY (`idUser`) REFERENCES `User` (`idUser`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
